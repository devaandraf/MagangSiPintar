<header>
    <div class="header-area ">
        <div id="sticky-header" class="main-header-area">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-2 col-lg-2">
                        <div class="logo">
                            <a href="<?= base_url()?>index.php">
                                <img style="width: auto;height: 40px" src="<?= base_url()?>assets/img/logosipintar.png" alt="" title="" />
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-10 col-lg-8">
                        <nav id="nav-menu-container">
                        <ul class="nav-menu sf-js-enabled sf-arrows" style="touch-action: pan-y;">
                            <li><a href="<?= site_url("Home_admin")?>">Home</a></li>
                            
                            <li class="menu-has-children"><a href="#" class="sf-with-ul">Perdagangan</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("N_perdagangan")?>">Neraca Perdangan</a></li>
                                    <li><a href="<?= site_url("show/Hub_dagang")?>">Hubungan Dagang</a></li>
                                    <li><a href="<?= site_url("forecast")?>">Forecasting</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#" class="sf-with-ul">Renc. Agenda</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("I_agenda")?>">Pameran Dalam Negeri</a></li>
                                    <li><a href="<?= site_url("I_agenda/LN")?>">Promosi Luar Negeri</a></li>
                                </ul>
                            </li>
                            <li><a href="<?= site_url("Agenda")?>">Agenda</a></li>
                               <li class="menu-has-children"><a href="#" class="sf-with-ul">Tampil Data</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("show/T_Ekspor")?>">Data Ekspor</a></li>
                                    <li><a href="<?= site_url("show/T_Impor")?>">Data Impor</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><img style="width: 27px" src="<?= base_url()?>assets/img/44948.png">
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("User")?>">Managemen User</a></li>
                                    <li><a href="<?= site_url("Logout")?>">Logout</a></li>
                                </ul>

                            </li>
                        </ul>
                    </nav>
                    </div>
                   <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</header>
