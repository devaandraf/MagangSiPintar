<meta http-equiv="x-ua-compatible" content="ie=edge">

 <!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Favicon-->
        <link rel="shortcut icon" href="<?= base_url()?>img/fav.png">
        <!-- Author Meta -->
        <meta name="author" content="colorlib">
        <!-- Meta Description -->
        <meta name="description" content="">
        <!-- Meta Keyword -->
        <meta name="keywords" content="">
        <!-- meta character set -->
        <meta charset="UTF-8">
        <!-- Site Title -->
        <title>SiPintar</title>
        <link href="<?= base_url() ?>assets/css/theme.css" rel="stylesheet" media="all">

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet">
        <!--
        CSS
        ============================================= -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/linearicons.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/bootstrap.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/magnific-popup.css">
        <!--<link rel="stylesheet" href="<?= base_url()?>assets/css/jquery-ui.css">-->
        <link rel="stylesheet" href="<?= base_url()?>assets/css/nice-select.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/animate.min.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/owl.carousel.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css/main.css">

        <link rel="stylesheet" href="<?= base_url()?>seogo/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/magnific-popup.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/themify-icons.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/nice-select.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/flaticon.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/gijgo.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/animate.min.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/slick.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/slicknav.css">
        <link rel="stylesheet" href="<?= base_url()?>seogo/css/style.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/datepicker/datepicker3.css">
<!-- daterange picker -->
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/daterangepicker/daterangepicker-bs3.css">
<style>

    .form-control{
    margin: 20px 5px;
    outline:solid 2px silver;
}
.form-control:focus{
    outline:solid 2px #8490ff;
}

</style>
