

<script src="<?= base_url()?>assets/js/vendor/jquery-2.2.4.min.js"></script>
<script src="<?= base_url()?>assets/js/popper.min.js"></script>
<script src="<?= base_url()?>assets/js/vendor/bootstrap.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
<script src="<?= base_url()?>assets/js/easing.min.js"></script>
<script src="<?= base_url()?>assets/js/hoverIntent.js"></script>
<script src="<?= base_url()?>assets/js/superfish.min.js"></script>
<script src="<?= base_url()?>assets/js/jquery.ajaxchimp.min.js"></script>
<script src="<?= base_url()?>assets/js/jquery.magnific-popup.min.js"></script>
<script src="<?= base_url()?>assets/js/jquery.tabs.min.js"></script>
<script src="<?= base_url()?>assets/js/jquery.nice-select.min.js"></script>
<script src="<?= base_url()?>assets/js/isotope.pkgd.min.js"></script>
<script src="<?= base_url()?>assets/js/waypoints.min.js"></script>
<script src="<?= base_url()?>assets/js/jquery.counterup.min.js"></script>
<script src="<?= base_url()?>assets/js/simple-skillbar.js"></script>
<script src="<?= base_url()?>assets/js/owl.carousel.min.js"></script>
<script src="<?= base_url()?>assets/js/mail-script.js"></script>
<script src="<?= base_url()?>assets/js/main.js"></script>

<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/daterangepicker/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/daterangepicker/daterangepicker.js"></script>

<script src="<?php echo base_url(); ?>assets/datepicker/bootstrap-datepicker.js"></script>


<!--AMCHART JS-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.js" type="text/javascript"> </script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.bundle.min.js" type="text/javascript"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.js" type="text/javascript"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js" type="text/javascript"></script>

<!-- JS here -->

<script src="<?= base_url()?>seogo/js/vendor/modernizr-3.5.0.min.js"></script>
<script src="<?= base_url()?>seogo/js/ajax-form.js"></script>
<script src="<?= base_url()?>seogo/js/imagesloaded.pkgd.min.js"></script>
<script src="<?= base_url()?>seogo/js/scrollIt.js"></script>
<script src="<?= base_url()?>seogo/js/jquery.scrollUp.min.js"></script>
<script src="<?= base_url()?>seogo/js/wow.min.js"></script>
<script src="<?= base_url()?>seogo/js/nice-select.min.js"></script>
<script src="<?= base_url()?>seogo/js/jquery.slicknav.min.js"></script>
<script src="<?= base_url()?>seogo/js/plugins.js"></script>
<!-- <script src="<?= base_url()?>seogo/js/gijgo.min.js"></script> -->

<!--contact js-->
<script src="<?= base_url()?>seogo/js/contact.js"></script>
<script src="<?= base_url()?>seogo/js/jquery.form.js"></script>
<script src="<?= base_url()?>seogo/js/jquery.validate.min.js"></script>


<script src="<?= base_url()?>seogo/js/main.js"></script>
