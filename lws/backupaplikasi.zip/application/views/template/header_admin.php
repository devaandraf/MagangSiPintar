<!-- <header id="header">
            <div class="container main-menu">
                <div class="row align-items-center justify-content-between d-flex">
                    <div id="logo">
                        <a href="index.html"><img style="width: 130px;height: 30px" src="<?= base_url()?>assets/img/logosipintar.png" alt="" title="" /></a>
                    </div>
                    <nav id="nav-menu-container">
                        <ul class="nav-menu">
                            <li><a href="<?= base_url()?>index.php/Home_admin">Home</a></li> -->
<!--                            <li class="menu-has-children"><a href="#">EKSPOR</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/K_ekspor">KINERJA EKSPOR</a></li>
                                    <li><a href="<?= base_url()?>index.php/K_ekspor_sektor">EKSPOR NON MIGAS PER SEKTOR</a></li>
                                    <li><a href="<?= base_url()?>index.php/K_ekspor_peran">PERAN EKSPOR</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#">IMPOR</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/K_impor">KINERJA IMPOR</a></li>
                                    <li><a href="<?= base_url()?>index.php/K_impor_sektor">IMPOR NON MIGAS PER SEKTOR</a></li>
                                    <li><a href="<?= base_url()?>index.php/K_impor_peran">PERAN IMPOR</a></li>
                                </ul>
                            </li>-->
                            <!-- <li class="menu-has-children"><a href="#">Perdagangan</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/N_perdagangan">Neraca Perdangan</a></li>
                                    <li><a href="<?= base_url()?>index.php/show/Hub_dagang">Hubungan Dagang</a></li>
                                    <li><a href="<?= base_url()?>index.php/forecast">Forecasting</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#">Renc. Agenda</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/I_agenda">Pameran Dalam Negeri</a></li>
                                    <li><a href="<?= base_url()?>index.php/I_agenda/LN">Promosi Luar Negeri</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#">Input Data Ekspor</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/Data_ekspor_pusdatin">Ekspor - Upload Excel</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_ekspor_migas">Ekspor - Migas</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_ekspor">Ekspor - Non Migas</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_ekspor_komoditi/">Ekspor - Komoditi</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_ekspor_negara/">Ekspor - Negara</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#">Input Data Impor</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/Data_impor_pusdatin">Impor - Upload Excel</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_impor_migas">Impor - Migas</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_impor">Impor - Non Migas</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_impor_komoditi/">Impor - Komoditi</a></li>
                                    <li><a href="<?= base_url()?>index.php/Data_impor_negara/">Impor - Negara</a></li>
                                </ul>
                            </li>
                            <li><a href="<?= base_url()?>index.php/Agenda">Agenda</a></li> -->
                             <!--<li><a href="<?= base_url()?>index.php/show/T_Ekspor">Tampil Data</a></li>-->
                             <!-- <li class="menu-has-children"><a href="#">Tampil Data</a>
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/show/T_Ekspor">Data Ekspor</a></li>
                                    <li><a href="<?= base_url()?>index.php/show/T_Impor">Data Impor</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><img style="width: 27px" src="<?= base_url()?>assets/img/44948.png">
                                <ul>
                                    <li><a href="<?= base_url()?>index.php/User">Managemen User</a></li>
                                    <li><a href="<?= base_url()?>index.php/Logout">Logout</a></li>
                                </ul>

                            </li>
                        </ul>
                    </nav> -->
                    <!-- #nav-menu-container -->
                <!-- </div>
            </div>
        </header> -->

<header>
    <div class="header-area ">
        <div id="sticky-header" class="main-header-area">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-xl-2 col-lg-2">
                        <div class="logo">
                            <a href="<?= base_url()?>index.php">
                                <img style="width: auto;height: 40px" src="<?= base_url()?>assets/img/logosipintar.png" alt="" title="" />
                            </a>
                        </div>
                    </div>
                    <div class="col-xl-10 col-lg-8">
                        <!-- <div class="main-menu  d-none d-lg-block">
                            <nav>
                                <ul id="navigation">
                                    <li><a href="<?= base_url()?>index.php">Home</a></li>
                                    <li><a href="#">Perdagangan <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="<?= base_url()?>index.php/N_perdagangan">Neraca Perdangan</a></li>
                                            <li><a href="<?= base_url()?>index.php/show/Hub_dagang">Hubungan Dagang</a></li>
                                            <li><a href="<?= base_url()?>index.php/forecast">Forecasting</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Renc. Agenda <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="<?= base_url()?>index.php/I_agenda">Pameran Dalam Negeri</a></li>
                                            <li><a href="<?= base_url()?>index.php/I_agenda/LN">Promosi Luar Negeri</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Input Data Ekspor <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="<?= base_url()?>index.php/Data_ekspor_pusdatin">Ekspor - Upload Excel</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_ekspor_migas">Ekspor - Migas</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_ekspor">Ekspor - Non Migas</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_ekspor_komoditi/">Ekspor - Komoditi</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_ekspor_negara/">Ekspor - Negara</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Input Data Import <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="<?= base_url()?>index.php/Data_impor_pusdatin">Impor - Upload Excel</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_impor_migas">Impor - Migas</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_impor">Impor - Non Migas</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_impor_komoditi/">Impor - Komoditi</a></li>
                                            <li><a href="<?= base_url()?>index.php/Data_impor_negara/">Impor - Negara</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="<?= base_url()?>index.php/Agenda">Agenda</a></li>
                                    <li><a href="#">Tampil data <i class="ti-angle-down"></i></a>
                                        <ul class="submenu">
                                            <li><a href="<?= base_url()?>index.php/show/T_Ekspor">Data Ekspor</a></li>
                                            <li><a href="<?= base_url()?>index.php/show/T_Impor">Data Impor</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#"><img style="width: 27px" src="<?= base_url()?>assets/img/44948.png"></i></a>
                                        <ul class="submenu">
                                            <li><a href="<?= base_url()?>index.php/User">Managemen User</a></li>
                                            <li><a href="<?= base_url()?>index.php/Logout">Logout</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div> -->
                        <nav id="nav-menu-container">
                        <ul class="nav-menu sf-js-enabled sf-arrows" style="touch-action: pan-y;">
                            <li><a href="<?= site_url("Home_admin")?>">Home</a></li>
<!--                            <li class="menu-has-children"><a href="#">EKSPOR</a>
                                <ul>
                                    <li><a href="http://localhost/application/index.php/K_ekspor">KINERJA EKSPOR</a></li>
                                    <li><a href="http://localhost/application/index.php/K_ekspor_sektor">EKSPOR NON MIGAS PER SEKTOR</a></li>
                                    <li><a href="http://localhost/application/index.php/K_ekspor_peran">PERAN EKSPOR</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#">IMPOR</a>
                                <ul>
                                    <li><a href="http://localhost/application/index.php/K_impor">KINERJA IMPOR</a></li>
                                    <li><a href="http://localhost/application/index.php/K_impor_sektor">IMPOR NON MIGAS PER SEKTOR</a></li>
                                    <li><a href="http://localhost/application/index.php/K_impor_peran">PERAN IMPOR</a></li>
                                </ul>
                            </li>-->
                            <li class="menu-has-children"><a href="#" class="sf-with-ul">Perdagangan</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("N_perdagangan")?>">Neraca Perdangan</a></li>
                                    <li><a href="<?= site_url("show/Hub_dagang")?>">Hubungan Dagang</a></li>
                                    <li><a href="<?= site_url("forecast")?>">Forecasting</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#" class="sf-with-ul">Renc. Agenda</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("I_agenda")?>">Pameran Dalam Negeri</a></li>
                                    <li><a href="<?= site_url("I_agenda/LN")?>">Promosi Luar Negeri</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#" class="sf-with-ul">Input Data Ekspor</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("Data_ekspor_pusdatin")?>">Ekspor - Upload Excel</a></li>
                                    <li><a href="<?= site_url("Data_ekspor_migas")?>">Ekspor - Migas</a></li>
                                    <li><a href="<?= site_url("Data_ekspor")?>">Ekspor - Non Migas</a></li>
                                    <li><a href="<?= site_url("Data_ekspor_komoditi")?>">Ekspor - Komoditi</a></li>
                                    <li><a href="<?= site_url("Data_ekspor_negara")?>">Ekspor - Negara</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><a href="#" class="sf-with-ul">Input Data Impor</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("Data_impor_pusdatin")?>">Impor - Upload Excel</a></li>
                                    <li><a href="<?= site_url("Data_impor_migas")?>">Impor - Migas</a></li>
                                    <li><a href="<?= site_url("Data_impor")?>">Impor - Non Migas</a></li>
                                    <li><a href="<?= site_url("Data_impor_komoditi")?>">Impor - Komoditi</a></li>
                                    <li><a href="<?= site_url("Data_impor_negara")?>">Impor - Negara</a></li>
                                </ul>
                            </li>
                            <li><a href="<?= site_url("Agenda")?>">Agenda</a></li>
                             <!--<li><a href="http://localhost/application/index.php/show/T_Ekspor">Tampil Data</a></li>-->
                             <li class="menu-has-children"><a href="#" class="sf-with-ul">Tampil Data</a>
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("show/T_Ekspor")?>">Data Ekspor</a></li>
                                    <li><a href="<?= site_url("show/T_Impor")?>">Data Impor</a></li>
                                </ul>
                            </li>
                            <li class="menu-has-children"><img style="width: 27px" src="<?= base_url()?>assets/img/44948.png">
                                <ul style="display: none;">
                                    <li><a href="<?= site_url("User")?>">Managemen User</a></li>
                                    <li><a href="<?= site_url("Logout")?>">Logout</a></li>
                                </ul>

                            </li>
                        </ul>
                    </nav>
                    </div>
                    <!-- <div class="col-xl-2 col-lg-3 d-none d-lg-block">
                        <div class="Appointment">
                            <div class="book_btn d-none d-lg-block">
                                <a href="<?= base_url()?>index.php/Login">Login</a>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</header>
