<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <?php $this->load->view('template/css') ?>
    </head>
    <body>
       <?php
            if (!isset($this->session->userdata['user_role']) || $this->session->userdata['user_role'] == "") {
                $this->load->view('template/header');
            } elseif ($this->session->userdata['user_role'] == "ADMIN") {
                $this->load->view('template/header_admin');
            } elseif($this->session->userdata['user_role'] == "USER"){
                $this->load->view('template/header_user');
            }
            else {
                $this->load->view('template/header');
            }
            ?>
        <!-- start banner Area -->
        <!-- <section class="relative about-banner">
            <div class="overlay overlay-bg"></div>
            <div class="container">
                <div class="row d-flex align-items-center justify-content-center">
                    <div class="about-content col-lg-12">
                        <h1 class="text-white">
                            Neraca Perdagangan Jawa Timur Jan-Des
                        </h1>
                        <p class="text-white link-nav"><a href="<?= base_url() ?>index.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href=""> Kinerja</a></p>
                    </div>
                </div>
            </div>
        </section> -->
        <div class="bradcam_area">
                <div class="bradcam_shap">
                    <img src="<?= base_url() ?>seogo/img/ilstrator/bradcam_ils.png" alt="">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="bradcam_text text-center">
                                <h3>Neraca Perdagangan Jawa Timur Jan-Des</h3>
                                <!--<nav class="brad_cam_lists">-->
                                <!--    <ul class="breadcrumb">-->
                                <!--        <li class="breadcrumb-item"><a href="<?= base_url() ?>index.php">Home</a></li>-->
                                <!--        <li class="breadcrumb-item active" aria-current="page">Kinerja</li>-->
                                <!--      </ul>-->
                                <!--</nav>-->
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <!-- End banner Area -->

        <!-- Start contact-page Area -->
        <div class="service_area minus_padding">
            <div class="container">
                <div class="card-body card-block" >
                    <div class="row">
                        <div class="col-lg-6 offset-3" >
                            <div class="au-card m-b-30">
                                <div class="au-card-inner">
                                    <h3 class="title-2 m-b-40" style="text-align:center">Neraca Perdagangan Jawa Timur 2019</h3>
                                    <canvas id="pieChartgue"></canvas>
                                    <p style="text-align:center;"> Berdasarkan data Pusdatin</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <!-- End contact-page Area -->

        <!-- start footer Area -->
        <?php $this->load->view('template/footer') ?>
        <!-- End footer Area -->
        <?php $this->load->view('template/js') ?>
       <script>
            new Chart(document.getElementById("pieChartgue"),
                    {
                        "type": "pie",
                        "data": {
                            datasets: [{
                                    data: <?= json_encode($data_pie['nilaipie']) ?>,
                                    backgroundColor: ["rgba(255, 159, 64,1.0)", "rgba(235, 59, 90,1.0)"]
                                }],
                            // These labels appear in the legend and in the tooltips when hovering different arcs
                            labels: [
                                'EKSPOR',
                                'IMPOR',
                            ]
                        },
                        tooltipTemplate: function(label) { return '$' + label.value.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");}

                    });
        </script>
    </body>
</html>
