<!DOCTYPE html>
<html lang="zxx" class="no-js">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <?php $this->load->view('template/css') ?>
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css"/>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css"/>
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/boxicons@2.0.0/css/boxicons.min.css"/>


        <!-- <style>

            body {
                background: #f7f7f7;
            }

            .table {
                border-spacing: 0 0.85rem !important;
            }

            .table .dropdown {

                display: inline-block;
            }

            .table td,
            .table th {
                vertical-align: middle;
                margin-bottom: 10px;
                border: none;
            }

            .table thead tr,
            .table thead th {
                border: none;
                font-size: 12px;
                letter-spacing: 1px;
                text-transform: uppercase;
                background: transparent;
            }

            .table td {
                background: #fff;
            }

            .table td:first-child {
                border-top-left-radius: 10px;
                border-bottom-left-radius: 10px;
            }

            .table td:last-child {
                border-top-right-radius: 10px;
                border-bottom-right-radius: 10px;
            }

            .avatar {
                width: 2.75rem;
                height: 2.75rem;
                line-height: 3rem;
                border-radius: 50%;
                display: inline-block;
                background: transparent;
                position: relative;
                text-align: center;
                color: #868e96;
                font-weight: 700;
                vertical-align: bottom;
                font-size: 1rem;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
            }

            .avatar-sm {
                width: 2.5rem;
                height: 2.5rem;
                font-size: 0.83333rem;
                line-height: 1.5;
            }

            .avatar-img {
                width: 100%;
                height: 100%;
                -o-object-fit: cover;
                object-fit: cover;
            }

            .avatar-blue {
                background-color: #c8d9f1;
                color: #467fcf;
            }

            table.dataTable.dtr-inline.collapsed
            > tbody
            > tr[role="row"]
            > td:first-child:before,
            table.dataTable.dtr-inline.collapsed
            > tbody
            > tr[role="row"]
            > th:first-child:before {
                top: 28px;
                left: 14px;
                border: none;
                box-shadow: none;
            }

            table.dataTable.dtr-inline.collapsed > tbody > tr[role="row"] > td:first-child,
            table.dataTable.dtr-inline.collapsed > tbody > tr[role="row"] > th:first-child {
                padding-left: 48px;
            }

            table.dataTable > tbody > tr.child ul.dtr-details {
                width: 100%;
            }

            table.dataTable > tbody > tr.child span.dtr-title {
                min-width: 50%;
            }

            table.dataTable.dtr-inline.collapsed > tbody > tr > td.child,
            table.dataTable.dtr-inline.collapsed > tbody > tr > th.child,
            table.dataTable.dtr-inline.collapsed > tbody > tr > td.dataTables_empty {
                padding: 0.75rem 1rem 0.125rem;
            }

            div.dataTables_wrapper div.dataTables_length label,
            div.dataTables_wrapper div.dataTables_filter label {
                margin-bottom: 0;
            }

            @media (max-width: 767px) {
                div.dataTables_wrapper div.dataTables_paginate ul.pagination {
                    -ms-flex-pack: center !important;
                    justify-content: center !important;
                    margin-top: 1rem;
                }
            }

            .btn-icon {
                background: #fff;
            }
            .btn-icon .bx {
                font-size: 20px;
            }

            .btn .bx {
                vertical-align: middle;
                font-size: 20px;
            }

            .dropdown-menu {
                padding: 0.25rem 0;
            }

            .dropdown-item {
                padding: 0.5rem 1rem;
            }

            .badge {
                padding: 0.5em 0.75em;
            }

            .badge-success-alt {
                background-color: #d7f2c2;
                color: #7bd235;
            }

            .table a {
                color: #212529;
            }

            .table a:hover,
            .table a:focus {
                text-decoration: none;
            }

            table.dataTable {
                margin-top: 12px !important;
            }

            .icon > .bx {
                display: block;
                min-width: 1.5em;
                min-height: 1.5em;
                text-align: center;
                font-size: 1.0625rem;
            }

            .btn {
                font-size: 0.9375rem;
                font-weight: 500;
                padding: 0.5rem 0.75rem;
            }

            .avatar-blue {
                background-color: #c8d9f1;
                color: #467fcf;
            }

            .avatar-pink {
                background-color: #fcd3e1;
                color: #f66d9b;
            }
        </style> -->
    </head>
    <body>
        <?php
            if (!isset($this->session->userdata['user_role']) || $this->session->userdata['user_role'] == "") {
                $this->load->view('template/header');
            } elseif ($this->session->userdata['user_role'] == "ADMIN") {
                $this->load->view('template/header_admin');
            } elseif($this->session->userdata['user_role'] == "USER"){
                $this->load->view('template/header_user');
            }
            else {
                $this->load->view('template/header');
            }
            ?>

        <!-- banner -->
        <div class="bradcam_area">
                <div class="bradcam_shap">
                    <img src="<?= base_url() ?>seogo/img/ilstrator/bradcam_ils.png" alt="">
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="bradcam_text text-center">
                                <h3>DATA EKSPOR</h3>
                                <p style="text-align:center;"> Data Berdasarkan BPS</p>
                                <!--<nav class="brad_cam_lists">-->
                                <!--    <ul class="breadcrumb">-->
                                <!--        <li class="breadcrumb-item"><a href="<?= base_url() ?>index.php">Home</a></li>-->
                                <!--        <li class="breadcrumb-item"><a href="">Tampil Data</a></li>-->
                                <!--        <li class="breadcrumb-item active" aria-current="page">Data Ekspor</li>-->
                                <!--      </ul>-->
                                <!--</nav>-->
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <!-- end banner -->

        <!-- Start contact-page Area -->
        <div class="service_area minus_padding">
            <div class="container">
                <div class="card-body card-block" >
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="au-card m-b-30">
                                <div class="au-card-inner">
                                    <h3 class="title-2 m-b-40" style="text-align:center">Migas dan Non Migas Tahun <?= date('Y') ?></h3>
                                     <!--<p> Data Berdasarkan BPS</p>-->
                                    <canvas id="pieChartgue"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="au-card m-b-30">
                                <div class="au-card-inner">
                                    <h3 class="title-2 m-b-40" style="text-align:center">Sektor Non Migas Tahun <?= date('Y') ?></h3>
                                     <!--<p> Data Berdasarkan BPS</p>-->
                                    <canvas id="barChartgue"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="au-card m-b-30">
                        <div class="au-card-inner">
                            <table id="kinerja" class="table table-hover responsive nowrap" style="width:100%">
                                <h2 style="text-align:center">KINERJA EKSPOR JAWA TIMUR JAN-DES <?= date('Y') ?></h2>
                                    <p style="text-align:center;" >Data berdasarkan BPS</p>
                                <thead>
                                    <tr style="background: #c3c3c3;">
                                        <th>No</th>
                                        <th>Realisasi Ekspor</th>
                                        <th><?= date('Y')-3 ?></th>
                                        <th><?= date('Y')-2 ?></th>
                                        <th>Jan - Des <?= date('Y')-1 ?></th>
                                        <th>Jan - Des <?= date('Y') ?></th>
                                        <th>d(%)*</th>
                                        <th>Peran(%)</th>
                                    </tr>
                                </thead>
                                <tbody>


                                    <?php

                                    $datenow = "thn".date('Y');
                                    $date2 = "thn".(date('Y')-1);
                                    $date3 = "thn".(date('Y')-2);
                                    $date4 = "thn".(date('Y')-3);

                                    $total1 = 0;
                                    $total2 = 0;
                                    $total3 = 0;
                                    $total4 = 0;

                                    foreach ($kinerja as $value) {
                                        $total4 += $value->$datenow;
                                    }
                                    $i = 1;
                                    foreach ($kinerja as $key => $value) {
                                        $total1 += $value->$date4;
                                        $total2 += $value->$date3;
                                        $total3 += $value->$date2;
                                        ?>

                                        <tr>
                                            <td><?= $i++ ?></td>
                                            <td><?= $value->kategori ?></td>
                                            <td><?= number_format($value->$date4, 2, ",", ".") ?></td>
                                            <td><?= number_format($value->$date3, 2, ",", ".") ?></td>
                                            <td><?= number_format($value->$date2, 2, ",", ".") ?></td>
                                            <td><?= number_format($value->$datenow, 2, ",", ".") ?></td>
                                            <td><?= ($value->$date2) ? round(($value->$datenow - $value->$date2) / $value->$date2 * 100, 2) : 0 ?></td>
                                          <?php if($value->$datenow==0) {?>
                                            <td>-</td>
                                            <?php }else { ?>
                                            <td><?= round($value->$datenow / $total4 * 100, 2) ?></td>
                                            <?php }?>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td></td>
                                        <td>TOTAL</td>
                                        <td><?= number_format($total1, 2, ",", ".") ?></td>
                                        <td><?= number_format($total2, 2, ",", ".") ?></td>
                                        <td><?= number_format($total3, 2, ",", ".") ?></td>
                                        <td><?= number_format($total4, 2, ",", ".") ?></td>
                                        <td><?= ($total3) ? round(($total4 - $total3) / $total3 * 100, 2) : 0 ?></td>
                                        <td>100</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="col-lg-12">
                    <div class="au-card m-b-30">
                        <div class="au-card-inner">
                            <table id="sektor" class="table table-hover responsive nowrap" style="width:100%">
                                <h2 style="text-align:center">EKSPOR NON MIGAS PER SEKTOR <?= date('Y') ?></h2>
                                    <p style="text-align:center;" >Data berdasarkan BPS</p>
                                <thead>
                                    <tr style="background: #c3c3c3;">
                                        <th>No</th>
                                        <th>Realisasi Ekspor</th>
                                        <th><?= date('Y')-3 ?></th>
                                        <th><?= date('Y')-2 ?></th>
                                        <th>Jan - Des <?= date('Y')-1 ?></th>
                                        <th>Jan - Des <?= date('Y') ?></th>
                                        <th>d(%)*</th>
                                        <th>Peran(%)</th>

                                    </tr>
                                </thead>
                                <tbody>

                                    <?php

                                    $datenow = "thn".date('Y');
                                    $date2 = "thn".(date('Y')-1);
                                    $date3 = "thn".(date('Y')-2);
                                    $date4 = "thn".(date('Y')-3);


                                    $total4 = 0;

                                    foreach ($sektor as $value) {
                                        $total4 += $value->$datenow;
                                    }
                                    $i = 1;
                                    foreach ($sektor as $key => $value) {
                                        ?>

                                        <tr>
                                            <td><?= $i++ ?></td>
                                            <td><?= $value->sektor ?></td>
                                            <td><?= number_format($value->$date4, 2, ",", ".") ?></td>
                                            <td><?= number_format($value->$date3, 2, ",", ".") ?></td>
                                            <td><?= number_format($value->$date2, 2, ",", ".") ?></td>
                                            <td><?= number_format($value->$datenow, 2, ",", ".") ?></td>
                                            <td><?= ($value->$date2) ? round(($value->$datenow - $value->$date2) / $value->$date2 * 100, 2) : 0 ?></td>

                                            <?php if($value->$datenow==0) {?>
                                            <td>-</td>
                                            <?php }else { ?>
                                            <td><?= round($value->$datenow / $total4 * 100, 2) ?></td>
                                            <?php }?>
                                        </tr>
<?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="col-lg-12">
                    <div class="au-card m-b-30">
                        <div class="au-card-inner" style="overflow-x:auto">
                            <table id="komoditi" class="table table-hover responsive nowrap" style="width:100%">
                                <h2 style="text-align:center">10 KOMODITI EKSPOR UTAMA JAWA TIMUR <?php $item =  array_slice($negara, 0, 1); foreach($item as $key=> $value){?><?= substr($value->uploaded_at, 0,4)?><?php }?></h2>
                                    <p style="text-align:center;" >Data berdasarkan BPS</p>
                                <thead>
                                    <?php foreach ($komoditi as $key => $value) {?>
                                      <tr>
                                        <?php  if ($key==0) {?>
                                          <th><?=$value->hs?></th>
                                          <th><?=$value->uraian?></th>
                                          <th><?=$value->bulanA?></th>
                                          <th><?=$value->bulanB?></th>
                                          <th><?=$value->tahbulA?></th>
                                          <th><?=$value->tahbulB?></th>
                                          <th><?=$value->ytoy?></th>
                                          <th><?=$value->mtom?></th>
                                          <th><?=$value->sharebul?></th>
                                          <th><?=$value->sharetahun?></th>
                                      </tr>
                                </thead>
                                 <?php }else{?>
                                <tbody>
                                <tr>
                                    <td><?=$value->hs?></td>
                                    <td><?=$value->uraian?></td>
                                    <td><?=$value->bulanA?></td>
                                    <td><?=$value->bulanB?></td>
                                    <td><?=$value->tahbulA?></td>
                                    <td><?=$value->tahbulB?></td>
                                    <td><?=$value->ytoy?></td>
                                    <td><?=$value->mtom?></td>
                                    <td><?= $value->sharebul ?></td>
                                    <td><?= $value->sharetahun ?></td>
                                </tr>
                                     <?php }}?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="col-lg-12">
                    <div class="au-card m-b-30">
                        <div class="au-card-inner" style="overflow-x:auto">
                            <table id="negara" class="table table-hover responsive nowrap" style="width:100%">
                                <h2 style="text-align:center">10 NEGARA TUJUAN EKSPOR UTAMA JAWA TIMUR <?php $item =  array_slice($negara, 0, 1); foreach($item as $key=> $value){?><?= substr($value->uploaded_at, 0,4)?><?php }?></h2>
                                <p style="text-align:center;" >Data berdasarkan BPS</p>
                                <thead>
                                  <?php $i = 1;
                                  foreach ($negara as $key => $value) { ?>
                                    <tr>
                                      <?php  if ($key==0) {?>
                                          <th><?=$value->uraian?></th>
                                          <th><?=$value->bulanA?></th>
                                          <th><?=$value->bulanB?></th>
                                          <th><?=$value->tahbulA?></th>
                                          <th><?=$value->tahbulB?></th>
                                          <th><?=$value->ytoy?></th>
                                          <th><?=$value->mtom?></th>
                                          <th><?=$value->sharebul?></th>
                                          <th><?=$value->sharetahun?></th>
                                    </tr>
                                </thead>
                                <?php }else{?>
                                <tbody>
                                          <td><?= $value->uraian ?></td>
                                          <td><?= $value->bulanA ?></td>
                                          <td><?= $value->bulanB ?></td>
                                          <td><?= $value->tahbulA ?></td>
                                          <td><?= $value->tahbulB ?></td>
                                          <td><?= $value->ytoy ?></td>
                                          <td><?= $value->mtom ?></td>
                                          <td><?= $value->sharebul ?></td>
                                          <td><?= $value->sharetahun ?></td>
                                        </tr>
                                    <?php }} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End contact-page Area -->

        <!-- start footer Area -->
        <?php $this->load->view('template/footer') ?>
        <!-- End footer Area -->
<?php $this->load->view('template/js') ?>
        <!--<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>-->
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>

        <!--export datatable-->
        <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
        <script type="text/javascript">
                                            $(document).ready(function () {
                                                $("#kinerja").DataTable({
                                                    aaSorting: [],
                                                    responsive: true,
                                                    dom: 'Bfrtip',
                                                    buttons: [
                                                        {extend: 'excel', className: 'btn btn-success btn-sm'},
                                                        {extend: 'pdf', className: 'btn btn-danger btn-sm'}
                                                    ],
                                                    columnDefs: [
                                                        {
                                                            responsivePriority: 1,
                                                            targets: 0
                                                        },
                                                        {
                                                            responsivePriority: 2,
                                                            targets: -1
                                                        }
                                                    ]
                                                });

                                                $("#sektor").DataTable({
                                                    aaSorting: [],
                                                    responsive: true,
                                                    dom: 'Bfrtip',
                                                    buttons: [
                                                        {extend: 'excel', className: 'btn btn-success btn-sm'},
                                                        {extend: 'pdf', className: 'btn btn-danger btn-sm'}
                                                    ],
                                                    columnDefs: [
                                                        {
                                                            responsivePriority: 1,
                                                            targets: 0
                                                        },
                                                        {
                                                            responsivePriority: 2,
                                                            targets: -1
                                                        }
                                                    ]
                                                });

                                                $("#komoditi").DataTable({
                                                    aaSorting: [],
                                                    responsive: true,
                                                    dom: 'Bfrtip',
                                                    paging: false,
                                                    buttons: [
                                                        {extend: 'excel', className: 'btn btn-success btn-sm'},
                                                        {extend: 'pdf', className: 'btn btn-danger btn-sm'}
                                                    ],
                                                    columnDefs: [
                                                        {
                                                            responsivePriority: 1,
                                                            targets: 0
                                                        },
                                                        {
                                                            responsivePriority: 2,
                                                            targets: -1
                                                        }
                                                    ]
                                                });

                                                $("#negara").DataTable({
                                                    aaSorting: [],
                                                    responsive: true,
                                                    dom: 'Bfrtip',
                                                    paging: false,
                                                    buttons: [
                                                        {extend: 'excel', className: 'btn btn-success btn-sm'},
                                                        {extend: 'pdf', className: 'btn btn-danger btn-sm'}
                                                    ],
                                                    columnDefs: [
                                                        {
                                                            responsivePriority: 1,
                                                            targets: 0
                                                        },
                                                        {
                                                            responsivePriority: 2,
                                                            targets: -1
                                                        }
                                                    ]
                                                });

                                                $(".dataTables_filter input")
                                                        .attr("placeholder", "Search here...")
                                                        .css({
                                                            width: "300px",
                                                            display: "inline-block"
                                                        });

                                                $('[data-toggle="tooltip"]').tooltip();
                                            });

        </script>
        <script>
            new Chart(document.getElementById("pieChartgue"),
                    {
                        "type": "pie",
                        "data": {
                            datasets: [{
                                    data: <?= json_encode($data_pie['nilaipie']) ?>,
                                    backgroundColor: ["rgba(255, 159, 64,1.0)", "rgba(235, 59, 90,1.0)"]
                                }],
                            // These labels appear in the legend and in the tooltips when hovering different arcs
                            labels: [
                                'MIGAS',
                                'NONMIGAS',
                            ]
                        }
                    });

            var myChart = new Chart(document.getElementById("barChartgue"),
                    {
                        "type": "bar",
                        "data":
                                {
                                    "labels": <?= json_encode($data_bar['label']) ?>,
                                    "datasets": [{
                                            "label": "Jumlah",
                                            "data": <?= json_encode($data_bar['datague']) ?>,
                                            "fill": false,
                                            "backgroundColor": [
                                                "rgba(236, 94, 105)",
                                                "rgba(255, 159, 64)",
                                                "rgba(241, 194, 5)",
                                                "rgba(99, 203, 137)",
                                                "rgba(0, 112, 224)",
                                                "rgba(153, 102, 255)",
                                                "rgba(201, 203, 207)",
                                                "rgba(236, 94, 105)",
                                                "rgba(255, 159, 64)",
                                                "rgba(241, 194, 5)",
                                                "rgba(99, 203, 137)",
                                                "rgba(0, 112, 224)"
                                            ],
                                            "borderColor": [
                                                "rgb(236, 94, 105)",
                                                "rgb(255, 159, 64)",
                                                "rgb(241, 194, 5)",
                                                "rgb(99, 203, 137)",
                                                "rgb(0, 112, 224)",
                                                "rgb(153, 102, 255)",
                                                "rgb(201, 203, 207)",
                                                "rgba(236, 94, 105)",
                                                "rgba(255, 159, 64)",
                                                "rgba(241, 194, 5)",
                                                "rgba(99, 203, 137)",
                                                "rgba(0, 112, 224)"
                                            ],
                                            "borderWidth": 1
                                        }]
                                },
                        "options": {
                            "scales": {
                                "yAxes": [{
                                        ticks: {
                                            beginAtZero: true
                                        }
                                    }]
                            }
                        }
                    });
        </script>
    </body>
</html>
