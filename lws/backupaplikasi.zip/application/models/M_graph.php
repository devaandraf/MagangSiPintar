<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_graph extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    public function getPieNeraca(){
        $sql = "
                SELECT 
                D.nilai as nilai,
                D.tahun
                FROM 
                (SELECT SUM(a.nilai) as nilai,a.tahun from t_ekspor_sektor_pusdatin a where a.tahun='2019') D 

                UNION ALL

                SELECT 
                D.nilai as nilai,
                D.tahun
                FROM 
                (SELECT SUM(a.nilai) as nilai,a.tahun from t_impor_sektor_pusdatin a where a.tahun='2019') D 
                ";
        $result = $this->db->query($sql);
        return $result->result();
        
    }
    
    public function getPieKinerja(){
        $sql = "
                SELECT 
                D.kategori,
                D.nilai as thn2018
                FROM 
                (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_migas
                WHERE substr(bulan, 4,7) = '2018') D 

                UNION ALL

                SELECT 
                D.kategori,
                D.nilai as thn2018
                FROM 
                (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_sektor
                WHERE substr(bulan, 4,7) = '2018') D 
                ";
        $result = $this->db->query($sql);
        return $result->result();
        
    }
    
     
    public function getBarKinerja(){
      $sql =  " 
            SELECT 
            A.sektor,
            A.nilai as thn2016,
            B.nilai as thn2017,
            C.nilai as thn2018,
            D.nilai as thn2015
            FROM 
            (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '2016'
            group by sektor 
            ORDER BY sum(nilai) desc ) A

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '2017'
            group by sektor 
            ORDER BY sum(nilai) desc ) B on A.sektor = B.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '2018'
            group by sektor 
            ORDER BY sum(nilai) desc ) C on A.sektor = C.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '2015'
            group by sektor 
            ORDER BY sum(nilai) desc ) D on A.sektor = D.sektor";
           
        $result = $this->db->query($sql);
        return $result->result();
    }
     
    public function getPieKinerjaImpor(){
        $sql = "
                SELECT 
                D.kategori,
                D.nilai as thn2018
                FROM 
                (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_migas
                WHERE substr(bulan, 4,7) = '2018') D 

                UNION ALL

                SELECT 
                D.kategori,
                D.nilai as thn2018
                FROM 
                (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_sektor
                WHERE substr(bulan, 4,7) = '2018') D 
                ";
        $result = $this->db->query($sql);
        return $result->result();
        
    }
    
     public function getBarKinerjaImpor(){
      $sql =  " 
            SELECT 
            A.sektor,
            A.nilai as thn2016,
            B.nilai as thn2017,
            C.nilai as thn2018,
            D.nilai as thn2015
            FROM 
            (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '2016'
            group by sektor 
            ORDER BY sum(nilai) desc ) A

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '2017'
            group by sektor 
            ORDER BY sum(nilai) desc ) B on A.sektor = B.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '2018'
            group by sektor 
            ORDER BY sum(nilai) desc ) C on A.sektor = C.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '2015'
            group by sektor 
            ORDER BY sum(nilai) desc ) D on A.sektor = D.sektor";
           
        $result = $this->db->query($sql);
        return $result->result();
    }
    
     public function get_data_cdgraph() {
         $sql ="select sum(nilai) as nilai from t_ekspor_sektor_pusdatin where tahun = '2019'
                UNION ALL
                select sum(nilai) as nilai from t_impor_sektor_pusdatin where tahun = '2019'";
        $result = $this->db->query($sql);
        return $result->result();
    }
}
