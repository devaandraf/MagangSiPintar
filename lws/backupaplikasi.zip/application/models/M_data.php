<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_data extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    function login($email, $password) {
        $this->db->where('user_email', $email);
        $this->db->where('user_pass', md5($password));
        $result = $this->db->get('user');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return false;
        }
    }
    public function log_login($nama, $role,$email) {
        $this->db->insert('user_log', array('login' => date('Y-m-d H:i:s'), 
            'nama'      => $nama, 
            'user_role' => $role,
            'email'     => $email
                ));
        return $this->db->insert_id();
    }
     public function log_logout($id) {
        $this->db->where('id', $id);
        $this->db->update('user_log', array('logout' => date('Y-m-d H:i:s')));
    }
    
    //EKSPOR//
     public function getSektor($datenow){
         $date2 = $datenow-1 ;
        $date3 = $datenow-2 ;
        $date4 = $datenow-3 ;
      $sql =  " 
            SELECT 
            A.sektor,
            A.nilai as thn$date4,
            B.nilai as thn$date3,
            C.nilai as thn$date2,
            D.nilai as thn$datenow
            FROM 
            (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '$date4'
            group by sektor 
            ORDER BY sum(nilai) desc ) A

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '$date3'
            group by sektor 
            ORDER BY sum(nilai) desc ) B on A.sektor = B.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '$date2'
            group by sektor 
            ORDER BY sum(nilai) desc ) C on A.sektor = C.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 1,4) as bulan
            FROM t_ekspor_sektor
            WHERE substr(bulan, 4,7) = '$datenow'
            group by sektor 
            ORDER BY sum(nilai) desc ) D on A.sektor = D.sektor";
           
        $result = $this->db->query($sql);
        return $result->result();
    }
    
     public function getForecast(){
      $sql =  " 
            SELECT sum(nilai) as nilai,tahun, bulan FROM t_ekspor_sektor_pusdatin 
            WHERE tahun='2019' 
            GROUP BY bulan";
           
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    public function getForecastI(){
      $sql =  " 
            SELECT sum(nilai) as nilai,tahun, bulan FROM t_impor_sektor_pusdatin 
            WHERE tahun='2019' 
            GROUP BY bulan";
           
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    public function getKinerja($datenow){
        $date2 = $datenow-1 ;
        $date3 = $datenow-2 ;
        $date4 = $datenow-3 ;
        $sql = "
                SELECT 
                B.kategori,
                A.nilai as thn$date4,
                B.nilai as thn$date3,
                C.nilai as thn$date2,
                D.nilai as thn$datenow
                FROM 
                (SELECT id, kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_migas
                WHERE substr(bulan, 4,7) = '$date4') A

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7)as bulan
                FROM t_ekspor_migas
                WHERE substr(bulan, 4,7) = '$date3') B 

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_migas
                WHERE substr(bulan, 4,7) = '$date2') C 

                INNER JOIN (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_migas
                WHERE substr(bulan, 4,7) = '$datenow') D 

                UNION ALL

                SELECT 
                B.kategori,
                A.nilai as thn$date4,
                B.nilai as thn$date3,
                C.nilai as thn$date2,
                D.nilai as thn$datenow
                FROM 
                (SELECT id, kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_sektor
                WHERE substr(bulan, 4,7) = '$date4') A

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7)as bulan
                FROM t_ekspor_sektor
                WHERE substr(bulan, 4,7) = '$date3') B 

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_sektor
                WHERE substr(bulan, 4,7) = '$date2') C 

                INNER JOIN (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_ekspor_sektor
                WHERE substr(bulan, 4,7) = '$datenow') D 
                ";
//        print($sql);
//        die();
        $result = $this->db->query($sql);
        return $result->result();
        
    }
    // END EKSPOR//
    
    //IMPOR//
     public function getSektorI($datenow){
         $date2 = $datenow-1 ;
        $date3 = $datenow-2 ;
        $date4 = $datenow-3 ;
      $sql =  " 
            SELECT 
            A.sektor,
            A.nilai as thn$date4,
            B.nilai as thn$date3,
            C.nilai as thn$date2,
            D.nilai as thn$datenow
            FROM 
            (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '$date4'
            group by sektor 
            ORDER BY sum(nilai) desc ) A

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan,4,7) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '$date3'
            group by sektor 
            ORDER BY sum(nilai) desc ) B on A.sektor = B.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '$date2'
            group by sektor 
            ORDER BY sum(nilai) desc ) C on A.sektor = C.sektor

            LEFT JOIN (SELECT id, sektor, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
            FROM t_impor_sektor
            WHERE substr(bulan, 4,7) = '$datenow'
            group by sektor 
            ORDER BY sum(nilai) desc ) D on A.sektor = D.sektor";
           
//      print($sql);
//      die();
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    public function getKinerjaI($datenow){
        $date2 = $datenow-1 ;
        $date3 = $datenow-2 ;
        $date4 = $datenow-3 ;
        $sql = "
                SELECT 
                B.kategori,
                A.nilai as thn$date4,
                B.nilai as thn$date3,
                C.nilai as thn$date2,
                D.nilai as thn$datenow
                FROM 
                (SELECT id, kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_migas
                WHERE substr(bulan, 4,7) = '$date4') A

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7)as bulan
                FROM t_impor_migas
                WHERE substr(bulan, 4,7) = '$date3') B 

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_migas
                WHERE substr(bulan, 4,7) = '$date2') C 

                INNER JOIN (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_migas
                WHERE substr(bulan, 4,7) = '$datenow') D 

                UNION ALL

                SELECT 
                B.kategori,
                A.nilai as thn$date4,
                B.nilai as thn$date3,
                C.nilai as thn$date2,
                D.nilai as thn$datenow
                FROM 
                (SELECT id, kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_sektor
                WHERE substr(bulan, 4,7) = '$date4') A

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7)as bulan
                FROM t_impor_sektor
                WHERE substr(bulan, 4,7) = '$date3') B 

                INNER JOIN (SELECT id,kategori, sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_sektor
                WHERE substr(bulan, 4,7) = '$date2') C 

                INNER JOIN (SELECT id, kategori,sum(nilai) as nilai ,substr(bulan, 4,7) as bulan
                FROM t_impor_sektor
                WHERE substr(bulan, 4,7) = '$datenow') D 
                ";
        $result = $this->db->query($sql);
        return $result->result();
        
    }
    
    public function getNeraca(){
        $sql = " SELECT A.nilaiI,A.tahun,B.nilaiE FROM(
                    SELECT sum(nilai) as nilaiI, tahun from t_impor_sektor_pusdatin 
                    ) A 
                    LEFT JOIN (SELECT sum(nilai) as nilaiE, tahun from t_ekspor_sektor_pusdatin 
                    ) B on A.tahun = B.tahun
                    ";
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    public function getNeracaNegara($negara){
        $sql = " SELECT A.nilaiI,A.tahun,B.nilaiE,sum(B.nilaiE)- sum(A.nilaiI) as sur FROM(
                    SELECT sum(nilai) as nilaiI, tahun from t_impor_sektor_pusdatin WHERE nm_negara='$negara' group by tahun ORDER BY tahun desc
                    ) A 
                    LEFT JOIN (SELECT sum(nilai) as nilaiE, tahun from t_ekspor_sektor_pusdatin WHERE nm_negara='$negara' group by tahun ORDER BY tahun desc
                    ) B on A.tahun = B.tahun 
                    ";
        $result = $this->db->query($sql);
        return $result->result();
    }
    
     public function getNerEkspor($negara){
        $sql = "SELECT  A.tahun, format(A.nilai,2) as nilai, B.nilaiE as nilaiE, format(B.nilaiE /A.nilai*100,2) as share
                    FROM(
                    SELECT SUM(nilai) as nilai, tahun FROM t_ekspor_sektor_pusdatin group by tahun
                    ) A
                    INNER JOIN(
                    SELECT sum(nilai) as nilaiE, tahun  FROM t_ekspor_sektor_pusdatin where nm_negara='$negara' group by tahun
                    )B ON A.tahun = B.tahun";
//        echo $sql;
//        die();
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    public function getNerImpor($negara){
        $sql = "SELECT  A.tahun, format(A.nilai,2) as nilai, B.nilaiI as nilaiI,format(B.nilaiI /A.nilai*100,2) as share
                    FROM(
                    SELECT SUM(nilai) as nilai, tahun FROM t_impor_sektor_pusdatin group by tahun
                    ) A
                    INNER JOIN(
                    SELECT sum(nilai) as nilaiI, tahun  FROM t_impor_sektor_pusdatin where nm_negara='$negara' group by tahun
                    )B ON A.tahun = B.tahun";
//        echo $sql;die();
        $result = $this->db->query($sql);
        return $result->result();
    }
     public function getHubKomoEkspor($negara){
        $sql = "SELECT b.KD_HS2DIGIT as hs,b.URAIAN as uraian,format(sum(a.nilai),2) as nilai,a.berat from t_ekspor_sektor_pusdatin a 
                left join mst_komoditas	b on substr(a.btki,1,2) = b.KD_HS2DIGIT
                where nm_negara='$negara'
                 group by substr(btki,1,2) 
                order by sum(a.nilai) desc
                limit 10";
        $result = $this->db->query($sql);
        return $result->result();
    }
    public function getHubKomoImpor($negara){
        $sql = "SELECT b.KD_HS2DIGIT as hs,b.URAIAN as uraian,format(sum(a.nilai),2) as nilai,a.berat from t_impor_sektor_pusdatin a 
                left join mst_komoditas	b on substr(a.btki,1,2) = b.KD_HS2DIGIT
                where nm_negara='$negara'
                 group by substr(btki,1,2) 
                order by sum(a.nilai) desc
                limit 5";
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    
    //END IMPOR//
     public function getKomoditi(){
        $sql = "Select *from 
                (select*from t_ekspor_komoditi order by uploaded_at desc limit 14) a 
                order by a.id asc ";
       
        $result = $this->db->query($sql);
        return $result->result();
    }
     public function getKomoditiI(){
        $sql = "Select *from 
                (select*from t_impor_komoditi order by uploaded_at desc limit 14) a 
                order by a.id asc ";
       
        $result = $this->db->query($sql);
        return $result->result();
    }
    
    public function getNegaraE(){
        
        $sql = "Select *from 
                (select*from  t_ekspor_negara order by uploaded_at desc limit 14) a 
                order by a.id asc ";
       
        $result = $this->db->query($sql);
        return $result->result();
    }
    public function getNegaraI(){
        $sql = "Select *from 
                (select*from t_impor_negara order by uploaded_at desc limit 14) a 
                order by a.id asc ";
       
        $result = $this->db->query($sql);
        return $result->result();
    }
    
     public function getUser(){
         $result = $this->db->get('user');
        return $result->result();
    }
    
     public function getAgenda(){
        $result = $this->db->get('t_agenda');
        return $result->result();
    }
    public function getEksMigas(){
        $result = $this->db->get('t_ekspor_migas');
        return $result->result();
    }
    public function getEksNonMigas(){
        $result = $this->db->get('t_ekspor_sektor');
        return $result->result();
    }
    public function getImpMigas(){
        $result = $this->db->get('t_impor_migas');
        return $result->result();
    }
    public function getImpNonMigas(){
        $result = $this->db->get('t_impor_sektor');
        return $result->result();
    }
    
      public function getAgendaNull(){
        $this->db->where('flag','DALAM NEGERI');
        $this->db->where('nilai is null');
         $result = $this->db->get('t_agenda');
        return $result->result();
    }
    public function getAgendaNullLN(){
        $this->db->where('flag','LUAR NEGERI');
        $this->db->where('nilai is null');
         $result = $this->db->get('t_agenda');
        return $result->result();
    }
    public function getAgendaNotNull(){
        $this->db->where('nilai is not null');
         $result = $this->db->get('t_agenda');
        return $result->result();
    }
    public function updateAgenda($id, $data) {
        $this->db->where('id', $id);
        $result = $this->db->update('t_agenda',$data);
       return $result;
    }
    
    
    public function getHS(){
        $result = $this->db->get('mst_komoditas');
        return $result->result();
    }
    
    public function getNegara(){
       
        $result = $this->db->get('mst_negara');
        return $result->result();
    }
    
    public function uploadExcel($data) {
        $this->db->insert('t_ekspor_sektor_pusdatin', $data);
        $this->db->insert_id();
        return true;
    }
    
    public function uploadExcelKomoditas($data) {
        $this->db->insert('t_ekspor_komoditi', $data);
        $this->db->insert_id();
        return true;
    }
    public function uploadExcelKomoditasI($data) {
        $this->db->insert('t_impor_komoditi', $data);
        $this->db->insert_id();
        return true;
    }
    
    public function uploadExcelNegara($data) {
        $this->db->insert('t_ekspor_negara', $data);
        $this->db->insert_id();
        return true;
    }
    public function uploadExcelNegaraDtl($data) {
        $this->db->insert('t_ekspor_negara_dtl', $data);
        $this->db->insert_id();
        return true;
    }
    
    
    public function uploadExcelNegaraI($data) {
        $this->db->insert('t_impor_negara', $data);
        $this->db->insert_id();
        return true;
    }
    
    
    
    public function uploadExcelImpor($data) {
        $this->db->insert('t_impor_sektor_pusdatin', $data);
        $this->db->insert_id();
        return true;
    }
}
