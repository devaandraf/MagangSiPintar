<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class I_agenda extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
    
//        public function __construct() {
//            parent::__construct();
//            $this->load->model(array('m_input'));
//            //        if (!$this->session->userdata('logged_in')) {
//                //            redirect('login');
//            //        }
//        }
        public function __construct() {
            parent::__construct();
            $this->load->model(array('m_data'));
            //        if (!$this->session->userdata('logged_in')) {
                //            redirect('login');
            //        }
        }
	public function index()
	{       
                $data['agendanull'] = $this->m_data->getAgendaNull();
		$this->load->view('i_agenda',$data);
	}
        
        public function LN()
	{
                $data['agendanull'] = $this->m_data->getAgendaNullLN();
		$this->load->view('i_agenda_luar',$data);
	}
        
        
        public function inputAgenda(){
            $this->load->model('m_input');
            $this->load->library('form_validation');
            $this->form_validation->set_rules('nm_agenda', 'nm_agenda', 'required');
                if ($this->form_validation->run() === TRUE) {

                    $insert = array(
                        'nama_agenda'       => $this->input->post('nm_agenda'),
                        'tanggal_agenda'    => date_format(date_create($this->input->post('tgl_agenda')), 'Y-m-d'),
                        'nama_kota'         => $this->input->post('nm_kota'),
                        'lokasi_agenda'     => $this->input->post('lksi_agenda'),
                        'flag'              => "DALAM NEGERI"
                              );

                    $this->m_input->insertAgenda($insert);
                    redirect('I_agenda');
                }
            else {
                $this->load->view('I_agenda');
            }
        }
        
        public function inputAgendaLuar(){
             $this->load->model('m_input');
            $this->load->library('form_validation');
            $this->form_validation->set_rules('nm_agenda', 'nm_agenda', 'required');
                if ($this->form_validation->run() === TRUE) {

                    $insert = array(
                        'nama_agenda'       => $this->input->post('nm_agenda'),
                        'tanggal_agenda'    => date_format(date_create($this->input->post('tgl_agenda')), 'Y-m-d'),
                        'nama_kota'         => $this->input->post('nm_kota'),
                        'lokasi_agenda'     => $this->input->post('lksi_agenda'),
                        'flag'              => "LUAR NEGERI"
                              );

                    $this->m_input->insertAgenda($insert);
                    redirect('I_agenda/LN');
                }
            else {
                $this->load->view('I_agenda_luar');
            } 
        }
        
}
