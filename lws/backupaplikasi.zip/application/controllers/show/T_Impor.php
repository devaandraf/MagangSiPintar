<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class T_Impor extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    
    
    
        public function __construct() {
            parent::__construct();
            $this->load->model(array('M_data','M_graph'));
    //        if (!$this->session->userdata('logged_in')) {
    //            redirect('login');
    //        }
        }
	public function index()
	{
                $datenow =  date("Y");
                $data['kinerja']    = $this->M_data->getKinerjaI($datenow);
                $data['sektor']     = $this->M_data->getSektorI($datenow);
                $data['komoditi']   = $this->M_data->getKomoditiI();
                $data['negara']     = $this->M_data->getNegaraI();
                
                
                //===================CHART JS===================//
                $result     = $this->M_graph->getPieKinerjaImpor();
                $nilaipie   = array();
                foreach ($result as $key => $value) {
                    array_push($nilaipie, (int) $value->thn2018);
                }
                $data['data_pie']['nilaipie'] = $nilaipie;
                
                //GRAPH BAR DASHBOARD//
                $result = $this->M_graph->getBarKinerjaImpor();
                $label = array();
                $datague = array();
                foreach ($result as $key => $value) {
                    array_push($label, $value->sektor);
                    array_push($datague, $value->thn2018);
                }
                $data['data_bar']['label'] = $label;
                $data['data_bar']['datague'] = $datague;

                //===================END CHART JS===================//
                
                
		$this->load->view('impor/t_impor',$data);
	}
        
}
